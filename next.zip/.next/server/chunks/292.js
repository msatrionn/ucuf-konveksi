"use strict";
exports.id = 292;
exports.ids = [292];
exports.modules = {

/***/ 9110:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/black.04b0e3c2.jpg","height":667,"width":1000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAqAz/AP/EABwQAQACAQUAAAAAAAAAAAAAAAIBBAMABRITQf/aAAgBAQABPwDBftLfrtVM9AqYWTx9Uzr/xAAVEQEBAAAAAAAAAAAAAAAAAAAAAv/aAAgBAgEBPwCX/8QAFREBAQAAAAAAAAAAAAAAAAAAAAL/2gAIAQMBAT8Ap//Z","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 5057:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blue.b9cf06ad.jpg","height":667,"width":1000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAvA5f/8QAGRABAQEAAwAAAAAAAAAAAAAAAwIBAAVh/9oACAEBAAE/AGZp7gBxawqC72fZ3n//xAAaEQEAAQUAAAAAAAAAAAAAAAABAwACITHB/9oACAECAQE/AJACLG7Otf/EABoRAQABBQAAAAAAAAAAAAAAAAECAAMhMcH/2gAIAQMBAT8Agq3M6nyv/9k=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 4507:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/brown.a5eefa61.jpg","height":667,"width":1000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAALkR/8QAHBAAAQQDAQAAAAAAAAAAAAAAAwECERIABRSC/9oACAEBAAE/AAnKu0eOy05Guj1Gf//EABYRAAMAAAAAAAAAAAAAAAAAAAABQf/aAAgBAgEBPwBU/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAFBcf/aAAgBAwEBPwBzD//Z","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 5269:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/maroon.a903e4c2.jpg","height":1000,"width":667,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAL8Ff//EABwQAAEFAAMAAAAAAAAAAAAAAAMBAgQFEgAUIv/aAAgBAQABPwChlmlvtTlVue68Y/OVyPn/xAAWEQADAAAAAAAAAAAAAAAAAAAAATH/2gAIAQIBAT8AUP/EABcRAAMBAAAAAAAAAAAAAAAAAAABAjL/2gAIAQMBAT8AvTP/2Q==","blurWidth":5,"blurHeight":8});

/***/ }),

/***/ 489:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/white.e9b6a1fb.jpg","height":667,"width":1000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAAKIKD//EABgQAAIDAAAAAAAAAAAAAAAAAAABAgNR/9oACAEBAAE/AJWvD//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 1292:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _CardProduct__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1068);
/* harmony import */ var _public_image_brown_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4507);
/* harmony import */ var _public_image_black_jpg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9110);
/* harmony import */ var _public_image_white_jpg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(489);
/* harmony import */ var _public_image_maroon_jpg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5269);
/* harmony import */ var _public_image_blue_jpg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5057);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_8__]);
axios__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const CardListProduct = ({ search  })=>{
    console.log(search);
    const [datas, setDatas] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const getData = ()=>{
        axios__WEBPACK_IMPORTED_MODULE_8__["default"].get("https://api.ucuf-konveksi.ucufkonveksi.com/api/admin/" + "product-all", {
            params: {
                search: search
            }
        }).then((result)=>{
            setDatas(result.data.data);
        }).catch((err)=>{
            console.log(err);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    }, [
        search
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-wrap justify-center",
                children: datas?.map((item)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CardProduct__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            id: item.idProduct,
                            photo: item.photoProduct,
                            description: item.title,
                            price: item.productdetails[0] ? " " + item.productdetails[0].price : " -",
                            // item={item}
                            details: item.productdetails
                        })
                    }, item.idProduct);
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardListProduct);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;