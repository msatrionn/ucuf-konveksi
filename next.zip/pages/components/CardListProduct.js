import React, { useEffect, useState } from "react";
import CardProduct from "./CardProduct";
import Brown from "../../public/image/brown.jpg";
import Black from "../../public/image/black.jpg";
import White from "../../public/image/white.jpg";
import Maroon from "../../public/image/maroon.jpg";
import Blue from "../../public/image/blue.jpg";
import axios from "axios";

const CardListProduct = ({ search }) => {
  console.log(search);

  const [datas, setDatas] = useState([]);
  const getData = () => {
    axios
      .get(
        "https://api.ucuf-konveksi.ucufkonveksi.com/api/admin/" + "product-all",
        {
          params: { search: search },
        }
      )
      .then((result) => {
        setDatas(result.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    getData();
  }, [search]);

  return (
    <div>
      <>
        <div className="flex flex-wrap justify-center">
          {datas?.map((item) => {
            return (
              <div key={item.idProduct}>
                <CardProduct
                  id={item.idProduct}
                  photo={item.photoProduct}
                  description={item.title}
                  price={
                    item.productdetails[0]
                      ? " " + item.productdetails[0].price
                      : " -"
                  }
                  // item={item}
                  details={item.productdetails}
                  // promoPrice={item.productPrice}
                  // type={item.type}
                />
              </div>
            );
          })}
        </div>
      </>
    </div>
  );
};

export default CardListProduct;
