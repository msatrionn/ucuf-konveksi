"use strict";
exports.id = 68;
exports.ids = [68];
exports.modules = {

/***/ 1068:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_CardProduct)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/image/Vector.svg
/* harmony default export */ const Vector = ({"src":"/_next/static/media/Vector.6076499d.svg","height":14,"width":24});
;// CONCATENATED MODULE: ./pages/components/CardProduct.js




const CardProduct = ({ id , photo , description , price , details  })=>{
    const [showModal, setShowModal] = (0,external_react_.useState)(false);
    const [age, setAge] = (0,external_react_.useState)("dewasa");
    const [size, setSize] = (0,external_react_.useState)("l");
    const [qty, setQty] = (0,external_react_.useState)(0);
    const [Check, setCheck] = (0,external_react_.useState)([]);
    const [Item, setItem] = (0,external_react_.useState)([]);
    const [Ages, setAges] = (0,external_react_.useState)("dewasa");
    const [Price, setPrice] = (0,external_react_.useState)(price);
    const [Material, setMaterial] = (0,external_react_.useState)("30s");
    const [Type, setType] = (0,external_react_.useState)("pendek");
    const handleAdult = (item, e)=>{
        const datas = [];
        if (e.target.checked) {
            setPrice(item.price);
            datas.push(item.size);
            setCheck(item.size);
        }
        setAge("dewasa");
        setQty(1);
        setSize("");
    };
    const DataDetail = [];
    details?.map((item)=>{
        if (item.age === Ages && item.type === Type && item.material === Material) {
            DataDetail.push(item);
        }
    });
    const dataXS = [];
    const dataS = [];
    const dataM = [];
    const dataL = [];
    const dataXL = [];
    const dataXXL = [];
    const dataXXXL = [];
    const dataXXXXL = [];
    DataDetail?.map((item)=>{
        if (item.size == "xs") {
            dataXS.push(item);
        } else if (item.size == "s") {
            dataS.push(item);
        } else if (item.size == "m") {
            dataM.push(item);
        } else if (item.size == "l") {
            dataL.push(item);
        } else if (item.size == "xl") {
            dataXL.push(item);
        } else if (item.size == "xxl") {
            dataXXL.push(item);
        } else if (item.size == "xxxl") {
            dataXXXL.push(item);
        } else if (item.size == "xxxxl") {
            dataXXXXL.push(item);
        }
    });
    const redirectWhatsApp = (Item)=>{
        if (Item[0]?.stock < 1) {
            alert("Silahkan pilih ukuran terlebih dahulu");
        } else {
            window.open(`https://wa.me/6282322109841?text=Hi,%20saya%20ingin%20pesan%20kaos%20${description}%20versi%20${age}%20dengan%20ukuran%20${size}%20,%20apakah%20tersedia?`, "_blank");
        }
    };
    (0,external_react_.useEffect)(()=>{
        Item?.map((data)=>{
            setSize(data.size);
            setPrice(data.price);
            setQty(data.stock);
        });
    }, [
        Item
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mx-auto w-fit p-2 drop-shadow-lg",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-64 h-fit group",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "relative overflow-hidden bg-white ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    className: "h-96 w-full object-cover",
                                    src: photo,
                                    alt: "",
                                    width: 600,
                                    height: 600,
                                    priority: true
                                }, id),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "absolute h-full w-full bg-black/20 flex items-center justify-center -bottom-10 group-hover:bottom-0 opacity-0 group-hover:opacity-100 transition-all duration-300",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "bg-blue-light text-java-blue active:bg-java-blue font-bold uppercase text-sm px-8 py-1 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
                                        type: "button",
                                        onClick: ()=>setShowModal(true),
                                        children: "Order"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-left pl-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "mt-3 text-xl capitalize mb-2",
                                            children: description ?? ""
                                        }, id),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "bg-blue-light text-java-blue p-1 text-xs",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-xs",
                                                    children: "RP"
                                                }),
                                                Price
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "pb-2"
                                        })
                                    ]
                                })
                            ]
                        })
                    }, id)
                })
            }),
            showModal ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "justify-center items-center flex fixed inset-0 z-50 outline-none focus:outline-none",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-white w-[70%] h-[95%] overflow-y-auto rounded-xl shadow-xl modal-container",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "max-w-md mx-auto bg-white overflow-hidden md:max-w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "flex mr-5 mt-2 justify-end cursor-pointer text-lg",
                                        onClick: ()=>setShowModal(false),
                                        children: "x"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "md:flex container-product",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "md:shrink-0 pl-10",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    width: 540,
                                                    height: 540,
                                                    className: "h-[100%] w-[full] object-cover md:w-[90%] container-image-product",
                                                    src: photo,
                                                    alt: "Modern building architecture"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "w-[40%] container-choose-product",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "w-full text-left flex justify-start mt-2",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "w-[50px] h-[60px]",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                    className: "text-md bg-blue-light p-2",
                                                                    children: [
                                                                        "#",
                                                                        id
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "text-md",
                                                                children: [
                                                                    description,
                                                                    " -",
                                                                    " ",
                                                                    Type == "no_rib" ? "Panjang no RIB" : Type == "panjang" ? "Panjang + RIB" : "Pendek"
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "bg-blue-light max-w-[100%] text-sm",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "text-left text-xl text-java-blue pl-2 pt-2",
                                                                children: [
                                                                    "Rp",
                                                                    Price
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text-left pl-2 italic text-gray-400 text-sm pb-1",
                                                                children: "Jaminan produk berkualitas 100% Ori"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex flex-col",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "container max-w-[100%] container-product-button text-sm",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "flex justify-start text-gray-400 mt-1 mb-1",
                                                                        children: "Jenis Usia"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 ",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                className: `flex border-2 rounded-md text-left text-java-blue pt-1 pb-1 pr-4 pl-4 cursor-pointer ${Ages == "dewasa" ? "bg-blue-light border-java-blue" : "border-gray-200"}`,
                                                                                onClick: ()=>setAges("dewasa"),
                                                                                children: [
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                        children: "Dewasa"
                                                                                    }),
                                                                                    Ages == "dewasa" ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                        src: Vector,
                                                                                        className: "ml-2",
                                                                                        alt: ""
                                                                                    }) : ""
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                className: `flex border-2 rounded-md text-left text-java-blue pt-1 pb-1 pr-4 pl-4 cursor-pointer ${Ages == "anak" ? "bg-blue-light border-java-blue" : "border-gray-200"}`,
                                                                                onClick: ()=>setAges("anak"),
                                                                                children: [
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                        children: "Anak"
                                                                                    }),
                                                                                    Ages == "anak" ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                        src: Vector,
                                                                                        className: "ml-2",
                                                                                        alt: ""
                                                                                    }) : ""
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "container max-w-[100%] container-product-button text-sm",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "flex justify-start text-gray-400 mt-1 mb-1",
                                                                        children: "Bahan"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                className: `flex border-2 rounded-md text-left text-java-blue pt-1 pb-1 pr-4 pl-4 cursor-pointer ${Material == "24s" ? "bg-blue-light border-java-blue" : "border-gray-200"}`,
                                                                                onClick: ()=>setMaterial("24s"),
                                                                                children: [
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                        children: "24S"
                                                                                    }),
                                                                                    Material == "24s" ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                        src: Vector,
                                                                                        className: "ml-2",
                                                                                        alt: ""
                                                                                    }) : ""
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                className: `flex border-2 rounded-md text-left text-java-blue pt-1 pb-1 pr-4 pl-4 cursor-pointer ${Material == "30s" ? "bg-blue-light border-java-blue" : "border-gray-200"}`,
                                                                                onClick: ()=>setMaterial("30s"),
                                                                                children: [
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                        children: "30S"
                                                                                    }),
                                                                                    Material == "30s" ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                        src: Vector,
                                                                                        className: "ml-2",
                                                                                        alt: ""
                                                                                    }) : ""
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "container max-w-[100%] container-product-button text-sm",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "flex justify-start text-gray-400 mt-1 mb-1",
                                                                        children: "Jenis"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                className: `flex border-2 rounded-md text-left text-java-blue pt-1 pb-1 pr-4 pl-4 cursor-pointer ${Type == "pendek" ? "bg-blue-light border-java-blue" : "border-gray-200"}`,
                                                                                onClick: ()=>setType("pendek"),
                                                                                children: [
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                        children: "Pendek"
                                                                                    }),
                                                                                    Type == "pendek" ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                        src: Vector,
                                                                                        className: "ml-2",
                                                                                        alt: ""
                                                                                    }) : ""
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                className: `flex border-2 rounded-md text-left text-java-blue pt-1 pb-1 pr-4 pl-4 cursor-pointer ${Type == "panjang" ? "bg-blue-light border-java-blue" : "border-gray-200"}`,
                                                                                onClick: ()=>setType("panjang"),
                                                                                children: [
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                        children: "Panjang"
                                                                                    }),
                                                                                    Type == "panjang" ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                        src: Vector,
                                                                                        className: "ml-2",
                                                                                        alt: ""
                                                                                    }) : ""
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                className: `flex border-2 rounded-md text-left text-java-blue pt-1 pb-1 pr-4 pl-4 cursor-pointer ${Type == "no_rib" ? "bg-blue-light border-java-blue" : "border-gray-200"}`,
                                                                                onClick: ()=>setType("no_rib"),
                                                                                children: [
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                        children: "Panjang no RIB"
                                                                                    }),
                                                                                    Type == "no_rib" ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                        src: Vector,
                                                                                        className: "ml-2",
                                                                                        alt: ""
                                                                                    }) : ""
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "max-w-md mx-auto bg-white overflow-hidden md:max-w-[920px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "md:flex",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "table-class mx-auto w-full pl-10 pr-10 flex justify-center",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex justify-between w-full flex-wrap",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "relative w-[400px] pb-4 overflow-x-auto sm:-mx-6 lg:-mx-8 sm:rounded-lg",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                                                        className: "w-full text-sm text-left text-gray-500 dark:text-gray-400",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                                                className: "text-xs text-gray-700 border-b border-black dark:bg-gray-700 dark:text-gray-400",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                            scope: "col",
                                                                            className: "px-8 py-1 text-xs text-gray-400",
                                                                            children: "Ukuran"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                            scope: "col",
                                                                            className: "px-8 py-1 text-xs text-gray-400",
                                                                            children: "Harga"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                            scope: "col",
                                                                            className: "text-xs text-gray-400",
                                                                            children: "Stok"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                        className: "bg-white border-b dark:bg-gray-900 dark:border-gray-700",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-1 text-xs",
                                                                                children: "XS"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-2 text-xs",
                                                                                children: dataXS.length > 0 ? dataXS?.map((item, key)=>{
                                                                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        children: item.price
                                                                                    }, key);
                                                                                }) : "-"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "text-xs",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    className: "flex items-center",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                            className: "mr-4 text-java-blue w-[20px]",
                                                                                            children: dataXS.length > 0 ? dataXS?.map((item, key)=>{
                                                                                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                    children: item.qty
                                                                                                }, key);
                                                                                            }) : "-"
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            className: "accent-java-blue w-4 h-4",
                                                                                            // disabled={item.qty == 0 ?? "true"}
                                                                                            // onChange={(e) => handleAdult(item, e)}
                                                                                            checked: size == "xs" ? true : false,
                                                                                            onChange: ()=>setItem([
                                                                                                    {
                                                                                                        size: "xs",
                                                                                                        price: dataXS.length > 0 ? dataXS[0].price : 0,
                                                                                                        stock: dataXS.length > 0 ? dataXS[0].qty : 0
                                                                                                    }
                                                                                                ])
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                        className: "bg-white border-b dark:bg-gray-900 dark:border-gray-700",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-1 text-xs",
                                                                                children: "S"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-2 text-xs",
                                                                                children: dataS.length > 0 ? dataS?.map((item, key)=>{
                                                                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        children: item.price
                                                                                    }, key);
                                                                                }) : "-"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "text-xs",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    className: "flex items-center",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                            className: "mr-4 text-java-blue w-[20px]",
                                                                                            children: dataS.length > 0 ? dataS?.map((item, key)=>{
                                                                                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                    children: item.qty
                                                                                                }, key);
                                                                                            }) : "-"
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            className: "accent-java-blue w-4 h-4",
                                                                                            // disabled={item.qty == 0 ?? "true"}
                                                                                            // onChange={(e) => handleAdult(item, e)}
                                                                                            checked: size == "s" ? true : false,
                                                                                            onChange: ()=>setItem([
                                                                                                    {
                                                                                                        size: "s",
                                                                                                        price: dataS.length > 0 ? dataS[0].price : 0,
                                                                                                        stock: dataS.length > 0 ? dataS[0].qty : 0
                                                                                                    }
                                                                                                ])
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                        className: "bg-white border-b dark:bg-gray-900 dark:border-gray-700",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-1 text-xs",
                                                                                children: "M"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-2 text-xs",
                                                                                children: dataM.length > 0 ? dataM?.map((item, key)=>{
                                                                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        children: item.price
                                                                                    }, key);
                                                                                }) : "-"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "text-xs",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    className: "flex items-center",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                            className: "mr-4 text-java-blue w-[20px]",
                                                                                            children: dataM.length > 0 ? dataM?.map((item, key)=>{
                                                                                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                    children: item.qty
                                                                                                }, key);
                                                                                            }) : "-"
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            className: "accent-java-blue w-4 h-4",
                                                                                            // disabled={item.qty == 0 ?? "true"}
                                                                                            // onChange={(e) => handleAdult(item, e)}
                                                                                            checked: size == "m" ? true : false,
                                                                                            onChange: ()=>setItem([
                                                                                                    {
                                                                                                        size: "m",
                                                                                                        price: dataM.length > 0 ? dataM[0].price : 0,
                                                                                                        stock: dataM.length > 0 ? dataM[0].qty : 0
                                                                                                    }
                                                                                                ])
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                        className: "bg-white border-b dark:bg-gray-900 dark:border-gray-700",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-1 text-xs",
                                                                                children: "L"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-2 text-xs",
                                                                                children: dataL.length > 0 ? dataL?.map((item, key)=>{
                                                                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        children: item.price
                                                                                    }, key);
                                                                                }) : "-"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "text-xs",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    className: "flex items-center",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                            className: "mr-4 text-java-blue w-[20px]",
                                                                                            children: dataL.length > 0 ? dataL?.map((item, key)=>{
                                                                                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                    children: item.qty
                                                                                                }, key);
                                                                                            }) : "-"
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            className: "accent-java-blue w-4 h-4",
                                                                                            // disabled={item.qty == 0 ?? "true"}
                                                                                            // onChange={(e) => handleAdult(item, e)}
                                                                                            checked: size == "l" ? true : false,
                                                                                            onChange: ()=>setItem([
                                                                                                    {
                                                                                                        size: "l",
                                                                                                        price: dataL.length > 0 ? dataL[0].price : 0,
                                                                                                        stock: dataL.length > 0 ? dataL[0].qty : 0
                                                                                                    }
                                                                                                ])
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "relative w-[400px] overflow-x-auto sm:-mx-6 lg:-mx-8 sm:rounded-lg",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                                                        className: "w-full text-sm text-left text-gray-500 dark:text-gray-400",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                                                className: "text-xs text-gray-700 border-b border-black dark:bg-gray-700 dark:text-gray-400",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                            scope: "col",
                                                                            className: "px-8 py-1 text-xs text-gray-400",
                                                                            children: "Ukuran"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                            scope: "col",
                                                                            className: "px-8 py-1 text-xs text-gray-400",
                                                                            children: "Harga"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                            scope: "col",
                                                                            className: "text-xs text-gray-400",
                                                                            children: "Stok"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                        className: "bg-white border-b dark:bg-gray-900 dark:border-gray-700",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-1 text-xs",
                                                                                children: "XL"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-2 text-xs",
                                                                                children: dataXL.length > 0 ? dataXL?.map((item, key)=>{
                                                                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        children: item.price
                                                                                    }, key);
                                                                                }) : "-"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "text-xs",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    className: "flex items-center",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                            className: "mr-4 text-java-blue w-[20px]",
                                                                                            children: dataXL.length > 0 ? dataXL?.map((item, key)=>{
                                                                                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                    children: item.qty
                                                                                                }, key);
                                                                                            }) : "-"
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            className: "accent-java-blue w-4 h-4",
                                                                                            // disabled={item.qty == 0 ?? "true"}
                                                                                            // onChange={(e) => handleAdult(item, e)}
                                                                                            checked: size == "xl" ? true : false,
                                                                                            onChange: ()=>setItem([
                                                                                                    {
                                                                                                        size: "xl",
                                                                                                        price: dataXL.length > 0 ? dataXL[0].price : 0,
                                                                                                        stock: dataXL.length > 0 ? dataXL[0].qty : 0
                                                                                                    }
                                                                                                ])
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                        className: "bg-white border-b dark:bg-gray-900 dark:border-gray-700",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-1 text-xs",
                                                                                children: "XXL"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-2 text-xs",
                                                                                children: dataXXL.length > 0 ? dataXXL?.map((item, key)=>{
                                                                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        children: item.price
                                                                                    }, key);
                                                                                }) : "-"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "text-xs",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    className: "flex items-center",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                            className: "mr-4 text-java-blue w-[20px]",
                                                                                            children: dataXXL.length > 0 ? dataXXL?.map((item, key)=>{
                                                                                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                    children: item.qty
                                                                                                }, key);
                                                                                            }) : "-"
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            className: "accent-java-blue w-4 h-4",
                                                                                            // disabled={item.qty == 0 ?? "true"}
                                                                                            // onChange={(e) => handleAdult(item, e)}
                                                                                            checked: size == "xxl" ? true : false,
                                                                                            onChange: ()=>setItem([
                                                                                                    {
                                                                                                        size: "xxl",
                                                                                                        price: dataXXL.length > 0 ? dataXXL[0].price : 0,
                                                                                                        stock: dataXXL.length > 0 ? dataXXL[0].qty : 0
                                                                                                    }
                                                                                                ])
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                        className: "bg-white border-b dark:bg-gray-900 dark:border-gray-700",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-1 text-xs",
                                                                                children: "XXXL"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-2 text-xs",
                                                                                children: dataXXXL.length > 0 ? dataXXXL?.map((item, key)=>{
                                                                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        children: item.price
                                                                                    }, key);
                                                                                }) : "-"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "text-xs",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    className: "flex items-center",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                            className: "mr-4 text-java-blue w-[20px]",
                                                                                            children: dataXXXL.length > 0 ? dataXXXL?.map((item, key)=>{
                                                                                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                    children: item.qty
                                                                                                }, key);
                                                                                            }) : "-"
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            className: "accent-java-blue w-4 h-4",
                                                                                            // disabled={item.qty == 0 ?? "true"}
                                                                                            // onChange={(e) => handleAdult(item, e)}
                                                                                            checked: size == "xxxl" ? true : false,
                                                                                            onChange: ()=>setItem([
                                                                                                    {
                                                                                                        size: "xxxl",
                                                                                                        price: dataXXXL.length > 0 ? dataXXXL[0].price : 0,
                                                                                                        stock: dataXXXL.length > 0 ? dataXXXL[0].qty : 0
                                                                                                    }
                                                                                                ])
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                        className: "bg-white border-b dark:bg-gray-900 dark:border-gray-700",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-1 text-xs",
                                                                                children: "XXXXL"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "px-8 py-2 text-xs",
                                                                                children: dataXXXXL.length > 0 ? dataXXXXL?.map((item, key)=>{
                                                                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        children: item.price
                                                                                    }, key);
                                                                                }) : "-"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                                className: "text-xs",
                                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    className: "flex items-center",
                                                                                    children: [
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                            className: "mr-4 text-java-blue w-[20px]",
                                                                                            children: dataXXXXL.length > 0 ? dataXXXXL?.map((item, key)=>{
                                                                                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                    children: item.qty
                                                                                                }, key);
                                                                                            }) : "-"
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                            type: "checkbox",
                                                                                            className: "accent-java-blue w-4 h-4",
                                                                                            checked: size == "xxxxl" ? true : false,
                                                                                            onChange: ()=>setItem([
                                                                                                    {
                                                                                                        size: "xxxxl",
                                                                                                        price: dataXXXXL.length > 0 ? dataXXXXL[0].price : 0,
                                                                                                        stock: dataXXXXL.length > 0 ? dataXXXXL[0].qty : 0
                                                                                                    }
                                                                                                ])
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-between bg-gray-100 flex-wrap wrapper-footers",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex mt-4 break-words ml-10 text-sm text-gray-500",
                                        children: "Perubahan data stok terakhir: 09 Januari 2023"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mr-7 flex justify-center text-sm mt-1 mb-1 items-center p-1 wrapper-footers-button",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                onClick: ()=>setShowModal(false),
                                                className: "text-java-blue p-2 pl-3 pr-3 rounded-md",
                                                children: "Kembali"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                onClick: ()=>redirectWhatsApp(Item),
                                                className: "bg-java-blue text-white p-1 pl-2 pr-2 rounded-md ml-4",
                                                children: "Beli Sekarang"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            }) : ""
        ]
    });
};
/* harmony default export */ const components_CardProduct = (CardProduct);


/***/ })

};
;